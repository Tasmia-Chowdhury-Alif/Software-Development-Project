/*

Topics:
1)Pointer
2)Dynamic memory allocation

Important Link:
visuaizer: https://pythontutor.com/visualize.html#mode=edit


Pointer:
1)What is pointer?
2)How to use?
3)What is Dereferencing
4)Example
5)Hack


Dynamic Memory Allocation:
1)How to declear for variable and array?
2)How to take input and show output?
3)Array increase size.
4)Return array and variable for funciton.
5)Actual use of Dynamic memory allocation




*/
