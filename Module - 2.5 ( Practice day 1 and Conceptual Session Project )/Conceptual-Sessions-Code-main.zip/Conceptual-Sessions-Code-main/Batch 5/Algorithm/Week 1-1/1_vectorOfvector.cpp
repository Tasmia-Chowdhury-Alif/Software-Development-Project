/**
 * All Praise to Allah
 * ---------------------
 * Author: Asif Mohammed Sifat
 * Created: 2024-09-02   16:01:13
 * Source:
 */
#include <bits/stdc++.h>
#define ll long long int
#define ull unsigned long long int
#define nl '\n'
using namespace std;

int main()
{
    //type-1
    vector<vector<int>>arr1;

    arr1.push_back(vector<int>());
    arr1.push_back(vector<int>());
    // arr1.push_back(vector<int>({1,2,3}));
    // arr1.push_back(vector<int>({4,5,6}));

    // arr1[0].push_back(7);

    cout<<arr1.size()<<endl;
    // cout<<arr1[0].size()<<endl;



    // for(int i=0;i<arr1.size();i++){
    //     for(int j=0;j<arr1[i].size();j++){
    //         cout<<arr1[i][j]<<" ";
    //     }
    //     cout<<endl;
        
    // }




    //type-2
    vector<vector<int>>arr2;


    return 0;
}


// vector<int> + a[2];
// vector<vector<int>>a;
// ei 2 tar vetor difference ase tahole