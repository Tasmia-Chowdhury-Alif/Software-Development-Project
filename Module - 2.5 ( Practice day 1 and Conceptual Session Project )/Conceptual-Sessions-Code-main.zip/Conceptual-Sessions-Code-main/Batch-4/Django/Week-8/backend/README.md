http://127.0.0.1:8000/api/posts/
http://127.0.0.1:8000/api/posts/<int>/

http://127.0.0.1:8000/api/auth/login/
http://127.0.0.1:8000/api/auth/logout/
http://127.0.0.1:8000/api/auth/reset/password/
http://127.0.0.1:8000/api/auth/reset/password/confirm/
http://127.0.0.1:8000/api/auth/register/

 
 
