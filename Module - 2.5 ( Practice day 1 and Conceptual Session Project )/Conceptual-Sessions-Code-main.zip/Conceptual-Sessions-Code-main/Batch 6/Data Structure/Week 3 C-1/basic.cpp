#include <bits/stdc++.h>
using namespace std;

int sum(int a, int b)
{ // implement this function to sum up two numbers
    int s = a + b;
    return s;
}

int main()
{

    int a, b;
    cin >> a >> b;
    cout << sum(a, b);
}