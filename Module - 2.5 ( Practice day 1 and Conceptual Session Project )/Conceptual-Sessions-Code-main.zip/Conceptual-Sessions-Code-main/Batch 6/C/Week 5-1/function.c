#include <stdio.h>

void add()
{
    int a, b;
    scanf("%d %d", &a, &b);

    printf("%d\n", a + b);
}

int main()
{
    add();
}