#include <bits/stdc++.h>
using namespace std;

int main()
{

    // erase

    string s = "HelloinWorld";
    // s.erase(5, 2);
    // cout << s << endl;

    // // after insertion

    // s.insert(5, "the");

    // cout << s << endl;

    // replace

    s.replace(5, 2, " ");

    cout << s << endl;
}