#include <bits/stdc++.h>
using namespace std;

int main()
{

    // string s = "hello";
    // string s1 = "hi";

    // s = s1; // strcpy

    string s;
    cin >> s;

    // string s1 = "hello";
    // s = s + 'n';

    s.pop_back(); // delete the last char

    cout << s << endl;
}