#include <bits/stdc++.h>
using namespace std;

int main()
{
    string s = "hellooworld";

    // find

    // pawa gele oi word tar prothom index dibe
    // pawa na gele -1 return korbe

    int pawa_gese = s.find("phitron");

    cout << pawa_gese << endl;
}