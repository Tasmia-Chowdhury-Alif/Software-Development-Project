#include <bits/stdc++.h>
using namespace std;

int main()
{

    string s; // dynamically
    cin >> s;

    for (auto it = s.begin(); it != s.end(); it++)
    {
        cout << *it << endl;
    }
}