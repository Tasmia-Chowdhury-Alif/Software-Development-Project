#include <bits/stdc++.h>
using namespace std;

int main()
{

    int *a = new int;

    cin >> *a;

    cout << *a << endl;
}