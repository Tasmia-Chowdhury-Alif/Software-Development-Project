#include <bits/stdc++.h>
using namespace std;

int main()
{

    int *arr = new int[3];

    for (int i = 0; i < 3; i++)
    {
        cin >> arr[i];
    }

    for (int i = 0; i < 3; i++)
    {
        cout << arr[i] << endl;
    }
}